
assignments = []

columns = "123456789"
rows = "ABCDEFGHI"

def cross(A, B):
    "Cross product of elements in A and elements in B."
    return [a+b for a in A for b in B]

# build boxes
boxes = cross(rows, columns)
# build units including row_units, column_units, square_units, diagonal_units
row_units = [cross(r,columns) for r in rows]
column_units = [cross(rows,c) for c in columns]
square_units = [cross(r,c) for r in ("ABC","DEF","GHI") for c in ("123","456","789")]
diagonal_units = [[r+c for r, c in zip(rows, columns)],[r+c for r, c in zip(rows[::-1], columns)]]
units_list = row_units + column_units + square_units + diagonal_units
units = {box:[units for units in units_list if box in units] for box in boxes}
peers = {box: (set(sum(unit,[]))-set([box])) for box, unit in units.items()}

def assign_value(values, box, value):
    """
    Please use this function to update your values dictionary!
    Assigns a value to a given box. If it updates the board record it.
    """

    # Don't waste memory appending actions that don't actually change any values
    if values[box] == value:
        return values

    values[box] = value
    if len(value) == 1:
        assignments.append(values.copy())
    return values


def grid_values(grid):
    """
    Convert grid into a dict of {square: char} with '123456789' for empties.
    Args:
        grid(string) - A grid in string form.
    Returns:
        A grid in dictionary form
            Keys: The boxes, e.g., 'A1'
            Values: The value in each box, e.g., '8'. If the box has no value, then the value will be '123456789'.
    """
    return {box: columns if value=="." else value for box, value in zip(boxes, grid)}


def display(values):
    """
    Display the values as a 2-D grid.
    Args:
        values(dict): The sudoku in dictionary form
    """
    width = 1 + max(len(values[s]) for s in boxes)
    line = '+'.join(['-' * (width * 3)] * 3)
    for r in rows:
        print(''.join(values[r + c].center(width) + ('|' if c in '36' else '')
                      for c in columns))
        if r in 'CF': print(line)
    return

def eliminate(values):
    solved_values = [box for box in values.keys() if len(values[box]) == 1]
    for box in solved_values:
        digit = values[box]
        for peer in peers[box]:
            new_value = values[peer].replace(digit, '')
            values = assign_value(values, peer, new_value)
    return values


def naked_twins(values):
    """Eliminate values using the naked twins strategy.
    Args:
        values(dict): a dictionary of the form {'box_name': '123456789', ...}

    Returns:
        the values dictionary with the naked twins eliminated from peers.
    """

    unresolved_values = {key: values[key] for key in values if len(values[key]) > 1}
    for box in unresolved_values:
        for unit in units[box]:
            # find naked twins
            naked_twins_val = ""
            for unit_box in unit:
                if(box != unit_box and len(values[box])==2 and values[box] == values[unit_box]):
                    naked_twins_val = values[box]
                    break
            # eliminate the naked twins value in that unit
            for unit_box in unit:
                if(values[unit_box]!=naked_twins_val):
                    new_value = "".join(sorted(set(values[unit_box])-set(naked_twins_val)))
                    values = assign_value(values, unit_box, new_value)

    return values



def only_choice(values):
    for unit in units_list:
        for digit in '123456789':
            dplaces = [box for box in unit if digit in values[box]]
            if len(dplaces) == 1:
                values[dplaces[0]] = digit
    return values


def reduce_puzzle(values):
    stalled = False
    while not stalled:
        solved_values_before = len([box for box in values.keys() if len(values[box]) == 1])
        values = eliminate(values)
        values = only_choice(values)
        values = naked_twins(values)
        solved_values_after = len([box for box in values.keys() if len(values[box]) == 1])
        stalled = solved_values_before == solved_values_after
        if len([box for box in values.keys() if len(values[box]) == 0]):
            return False
    return values


def search(values):
    result = reduce_puzzle(values)

    if result is False:
        return False;

    if all([len(value) == 1 for key, value in values.items()]):
        return values

    #1. find the least len box
    keyLenDict = {key: len(value) for key, value in values.items() if len(value) > 1}
    box, n = min(keyLenDict.items(), key=lambda x: x[1])

    #2.search
    for vals in values[box]:
        for fix_val in vals:
            newvalues = values.copy()
            newvalues[box] = fix_val
            tmp = search(newvalues)
            if tmp:
                return tmp



def solve(grid):
    """
    Find the solution to a Sudoku grid.
    Args:
        grid(string): a string representing a sudoku grid.
            Example: '2.............62....1....7...6..8...3...9...7...6..4...4....8....52.............3'
    Returns:
        The dictionary representation of the final sudoku grid. False if no solution exists.
    """
    values = grid_values(grid)
    values = search(values)
    return values


if __name__ == '__main__':
    diag_sudoku_grid = '9.1....8.8.5.7..4.2.4....6...7......5..............83.3..6......9................'
    display(solve(diag_sudoku_grid))

    try:
        from visualize import visualize_assignments
        visualize_assignments(assignments)

    except SystemExit:
        pass
    except:
        print('We could not visualize your board due to a pygame issue. Not a problem! It is not a requirement.')
